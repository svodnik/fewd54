// A function has already been written for you to get a random computer play.
// You can use the function to get a random play and store it in the computerPlay variable like so:

// getComputerPlay();

// You can then access the computer play by referencing the variable name computerPlay.

// Set up a variable to hold the computer's play.
var computerPlay;

function getComputerPlay() {
  // Store an array of options in the plays variable (we'll chat about arrays later in the class)
  var plays = ['rock', 'paper', 'scissors'];

  // Select a random option from the plays array (don't focus on this line too much) and store it in the computerPlay variable
  computerPlay = plays[Math.floor(Math.random() * plays.length)];
}

// WRITE YOUR CODE BELOW THIS LINE!