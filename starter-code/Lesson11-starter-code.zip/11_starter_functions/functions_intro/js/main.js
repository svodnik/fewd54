// Take a look at the below lines of code.
// Look at each function. Can you guess what will happen when the page loads?
// Open the page in your browser.
// What are the lines kitchenArea(), bathroomArea() and livingRoomArea() doing?
// Is there code that is repeated, or very similar in each function?
// Now work through the questions in part 2.

function kitchenArea () {
  var width = 10;
  var length = 14;

  var area = length * width;

  $('#rooms').append('<li>Kitchen: ' + area + ' square feet.</li>');
}


function bathroomArea () {
  var width = 8;
  var length = 10;

  var area = length * width;

  $('#rooms').append('<li>Bathroom: ' + area + ' square feet.</li>');
}


function livingRoomArea () {
  var width = 16;
  var length = 20;

  var area = length * width;

  $('#rooms').append('<li>Living Room: ' + area + ' square feet.</li>');
}

kitchenArea();
bathroomArea();
livingRoomArea();


// Part 2:

// After talking through the above questions, comment out the above code
// And uncomment the code below
// Take a look at what is in the parenthesis when the function is defined
// and when it is called. What do you think is happening here?

// function displayArea (room, length, width) {

//   var area = length * width;

//   $('#rooms').append('<li>' + room + ': ' + area + ' square feet.</li>');
// }



// displayArea('Kitchen', 14, 10);
// displayArea('Bathroom', 10, 8);
// displayArea('Living Room', 20, 16);