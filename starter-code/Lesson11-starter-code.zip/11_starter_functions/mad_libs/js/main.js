// Bug #1 - USE YOUR CONSOLE
// Nothing is working! Help! Use your console to figure out why.
// Then fix the 1 syntax Error.

$('p').hide();

$('form').on('submit', function (evt) {

	// Bug #2 - The page is refreshing when the form is submitted! 
	// Fix it so that the page does not refresh when the form 
	// is submitted.

	var author = $('#authorSelect').val();
	var noun = $('#nounInput').val();
	var verb = $('#verbInput').val();

	// Bug #3 - We are not getting a red border! 
	// Try not filling out the form and submitting it. 
	// Open Inspect and the "Elements" panel.
	// Is the class getting added?
	// Why might the styles not be getting applied?
	if (author === null) {
		$('#authorSelect')addClass('error');
	} else {
		$('#authorSelect').removeClass('error');
	}

	if (noun.length === 0) {
		$('#nounInput').addClass('error');
	} else {
		$('#nounInput').removeClass('error');
	}

	if (verb.length === 0) {
		$('#verbInput').addClass('error');
	} else {
		$('#verbInput').removeClass('error');
	}

	$('.quote').hide();

	if (author !== null && noun.length !== 0 && verb.length !== 0) {

		// Bug #4 - The carroll quote is always fading in, never the other quote. Why?
		// Use a breakpoint and the debugger ("sources" panel) to debug.
		// In the sources panel, pause the script here and hover over author to see what it holds
		if (author === 'seuss') {
			$('#suess').fadeIn(300);
		} else {
			$('#carroll').fadeIn(300);
		}
		
		$('.noun').text(noun);
		$('.verb').text(verb);
	}

});