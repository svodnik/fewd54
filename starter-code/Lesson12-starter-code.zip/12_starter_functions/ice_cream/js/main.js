
// -------------------------------------------------------------------------------
// Part 1 - Conditionals review
// -------------------------------------------------------------------------------

// Create a variable dayOfWeek that holds the value 'sunday'

// Create a variable customerChoice that holds the value 'berry crisp'

// Use console.log() to display the following text: "The customer wants a (customerChoice) cone."

// Check the console to make sure this message is displayed.

// Create an if statement for the following conditions:

// If the customer has chosen berry crisp and the day of the week is sunday
// OR if the customer has chosen vanilla and the day of the week is saturday
// OR if the customer has chosen salted caramel and the day of the week is friday
  // Display 'The price is $3.00' in the paragraph with the id #price

// otherwise
  // Display 'The price is $4.50' in the paragraph with the id #price


// Load the page in your browser and make sure the price is displayed.


// -------------------------------------------------------------------------------
// Part 2 - Creating a function
// -------------------------------------------------------------------------------
// Create a function buyIceCream
// Move the console.log() statement from part 1 into the function
// Call the function and check your console



// -------------------------------------------------------------------------------
// Part 3 - Parameters and arguments
// -------------------------------------------------------------------------------
// First delete the customerChoice variable you created in step 1.

// Create three click events, one for each button.

// When a button is clicked, call the buyIceCream function, 
// passing in the flavor as an argument

// add a parameter to the buyIceCream function - customerChoice

// Move the conditional (if/else statement) you created in part 1 into the function

// Test things out! When a button is clicked, the price should be displayed.

